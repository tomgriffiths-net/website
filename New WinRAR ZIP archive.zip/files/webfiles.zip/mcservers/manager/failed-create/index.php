<?php
require '../../../../localfiles/global.php';

html::head();
echo '
    
';
html::top("admin_mcservers");

echo 'Failed';

html::end();
echo '
    
';
html::end2();